# PMP -  规划风险应对(11.5)
@(PMP)[PMP-风险, PMP-规划风险应对, PMP-风险应对工具, 风险应对策略]

[toc]

## 1. 整体说明

规划风险应对（P436）- 为处理整体项目风险敞口，以及应对当个项目风险，而制定可选方案、选择应对策略并商定应对分析的过程。

本过程的主要作用是，制定应对整体项目风险和单个项目风险的适当方法；本过程还将分配资源，并根据需要将相关活动添加项目文件和项目管理计划。

本过程需要再整个项目期间开展。

**输出**：
- 变更请求
- 项目管理计划更新（进度、成本、质量、资源、采购管理计划； 范围、进度、成本基准）
- 项目文件更新（假设日志、成本预测、经验教训登记册、项目团队派工单、风险登记册、风险报告）

## 1.1 规划风险应对-工具与技术

![@||800x0](./1567388893186.png)


## 2. 风险应对工具与技术

### 2.1  应急应对策略 (Contingent Response Strategies)

![@||600x0](./1567388597605.png)


#### 1. 原计划 - 出国

#### 2. 应急计划 （Plan B /  Response Plan）- 考研
应急储备叫 Contingency Reserve, 应急储备一般是针对已识别出来风险但是不做任何处理，等风险发生的时候，再用这个储备cover掉。 所以感觉这个应急计划就是为应付应急储备而设置的？

**应对**：在进行持续时间估算是，需要考虑应急储备（又称为进度储备(Sometimes referred to as schedule reserves)），以应对进度方面的不确定性。 应急储备是包含在进度及准中的一段持续时间，用于应对已接受的已识别风险（已知-未知）。

**用法**：应急储备可取活动持续时间估算值的某一百分比或某一固定的时间段（关键路径法），也可以把应急储备从各个活动中剥离出来汇总（关键链法）。

**更新**：随着项目信息越来越明细，可以动用、减少或取消应急储备，应该在项目进度文件中清楚列出应急储备。

#### 3. 弹回计划 (For Back Plan / Resilience Plan) - 找工作
保底计划

#### 4. 权变措施 (Workaround) - 送外卖

### 2.2 威胁(即风险)应对策略

![@||800x0](./1567388384546.png)

#### 2.1 规避 

#####  2.1.1  优先级与影响较高=>规避
（冲3）51、 [单选] 在项目执行过程中，一位关键相关方对该项目经理实施一项风险规避策略的大量成本表示担心，项目经理应该告诉相关方什么信息？During project execution, a key stakeholder expresses concern about the significant cost of a risk avoidance strategy being implemented by the project manager.What should the project manager tell the stakeholder?

 A：如果这个风险变为现实，则项目成本可能高于高风险规避策略的成本 If the risk is realized, the cost of the project could be higher than the cost of the risk avoidance strategy
 
 B：这个风险变成现实的概率很高，因此风险规避成本是必要的 There is a high probability that the risk will be realized and. therefore, the risk avoidance counts are necessary.
 
 C：这个风险在风险登记册中的**优先级**和影响均较高 The risk has a high priority and impact on the risk register (窃以为：优先级高，说明已经做过定性分析，发生的概率高和影响面大，优先级才会排在前面)
 
 D：他们将终止风险规避策略以减少项目费用 They will terminate the risk avoidance strategy to reduce project expense

**正确答案：C；  你的答案：A**
>  解析：定位：（管理）规划风险应对。 说明解析：PMBOK（6）P447-11.5.2.4规划风险应对-规避。
>   
>  **规避策略适用于发生概率较高，且具有严重负面影响的高优先级威胁。所以即使成本高也应该采取规避策略**。
>   
>   选项A：**题目没有提到风险变为现实的话，成本什么情况**。 
>    
>  选项B：风险变成现实的概率很高，并不意味着规避成本必然高。 
>   
>  选项D：不能因为成本高就采取风险应对措施，如果确实需要，还需采取规避的应对策略。

#### 2.2  接受

#####  2.2.1  外包供应商导致一项新风险且无减轻计划 => 风险接受
（模1）155、 [单选] 在自制或外购分析之后，组织决定内部开发产品，但是功能测试将外包给战略供应商，这个决策导致记录了一项新风险，因为供应商可能结束业务，而这则没有风险减轻计划。这属于下列哪一项的实例？After a make-or-buy analysis the organization decides to develop the product internally, but functional testing will be outsourced to a strategic supplier. This decision result in the documentation of a new risk, because the supplier might go out of business and there is mitigation plan. This is an example of which of the following?

 A：由于人员配备不足将风险转移给供应商 Transferring risk to the supplier due to inadequate staffing
 B：回避进度偏移风险 Avoiding the risk of schedule slippage
 C：接受供应商结束业务风险 Accepting the risk of the supplier going out of business
 D：与新供应商谈判一项计划 Negotiation a plan with a new supplier
 
**正确答案：C；  你的答案：C**
> 解析：出处：11.5.2.41. 题干表明有一项测试外包，供应商可能结束业务，且无风险减轻计划；2. 接受是指承认威胁的存在，但不主动采取措施。

### 2.3 机会应对策略
![@||800x0](./1567388473986.png)

（冲1）47、 [单选] 在研究一个项目收购时，项目经理发现一种产品能够大大缩短上市时间并提供未来设计解决方案，但是由于该产品的供应商尚未符合行业标准，因此涉及的风险很大，项目经理下一步应该怎么做？ When researching a project acquisition, the project manager discovers a product that will considerably decrease the time to market and provide future design solutions. However, there is a large the risk involved,as the provider of this product is not yet industry compliant,. What should the project manager do next?

 A：联系该提供商并协商合作 Call the provider and negotiate a contract
 B：与开发团队开会，讨论下一步工作 Meet with the development team to discuss next steps
 C：C.实施风险管理计划及其中包含的己批准行动  Implement the risk management plan and the approved actions contained within it
 D：D.请项目管理办公室(PMO)批准继续 Ask the project management office (PMO) for approval to proceed

**正确答案：C 你的答案：B**
> 解析：参考答案：C 解析：机会中包括了风险，结合选项，应管理风险。C最好，ABD都没有考虑风险。风险管理计划中包含为了获得机会而可能遇到的风险及风险应对措施。

### 2.4 整体项目风险应对策略 Overall project risk response strategies
![@||800x0](./1567388799212.png)


## 3. 风险与资源的关系

| 风险种类      |    应对措施 |   动用资源   | 成本基准   | 管理责任   |备注|
| --------: | --------:| ------: |:------: |------: |------:|
| **已知**    |  原计划 |  活动预算  | √  |团队成员  ||
|**已知-已知**| 应急计划|应急储备|√ | 项目经理|
|**未知-未知** |权变措施 | 管理储备 | **`×`** |高层管理者|


## 4. Workaround v.s Contingency
原文链接：[PMP Exam Tip: What is the difference between Workaround and Contingency Plan?](http://www.cornelius-fichtner.com/index.php/pm/276-pmp-exam-tip-what-is-the-difference-between-workaround-and-contingency-plan)

The difference between the two terms is related to whether the problems being handled were identified ahead of time or not.

**Contingency**：
Contingency plans are made based on **potential risks that are identified** that could derail a project. 

**Workarounds**：
Workarounds are responses to problems that develop while the project is being worked that were **never identified.**


未知-未知风险，分权变措施和自动权变。

## 5. 相关习题 

### 5.1 在监督风险过程中发现了没有包含应对计划的新风险=>用权变措施 

（模3）129、 [单选] 项目经理正在管理一个软件开发项目的执行工作。在执行过程中，发生了一个风险应对计划中没有包括的风险。项目经理应该怎么做？ The project manager is managing the execution of a software development project. During the execution process, a risk that is not included in the risk response plan happens. What should the project manager do?

 A：使用应急储备来解决风险的后果 To solve the risk consequence with emergency reserves
 
 B：把风险的实际情况报告给管理层 To report the actual situation of the risk to the management
 
 C：召开团队会议讨论权变措施 To hold a team meeting to discuss workaround
 
 D：不理会这个风险，既然计划中没有包括 To ignore this risk, because this risk is not included in the plan.

**正确答案：C； 你的答案：B**
> 解析：PMBOK（6）P453-11.7监督风险。监督商定的风险应对计划的实施，跟踪已识别风险，识别和分析新风险，评估风险管理有效性。对于已经发生的未知-未知风险采用权变措施。

这题不选B的理由：
1. ~~**团队内部先讨论出措施，再看下内部能不能cover掉，也许有的风险小，根本不影响基准。**~~
2. **如果发现这个新识别出来的风险影响到了基准，已经无法handle了，需要找上级要管理储备。**
3. **既然题干提到了workaround，说明是启动了权变措施了，再上报之前需要现在团队内部讨论出方案再让管理层审批，因此先C后B**。

### 5.2 应急计划=>原来就设定了备胎供应商

(模3) 79、 [单选] 在项目执行过程中，指定供应商的仓库发生火灾，导致无法按计划为项目提供所需产品。为了不影响项目顺利执行，项目经理决定从**`原定备用供应商`**那里.采购所需产品。项目经理的做法属于？ During the project execution, in case of fire accident in the warehouse of the designated supplier, making it impossible to provide the required products as per the plan. To avoid affecting the smooth execution of the project, the project manager decides to purchase the required products from the original alternative supplier. What kind of his practice belongs to?

 A：执行权变措施 Execute contingency action
 
 B：执行弹回计划 Perform resilience plan
 
 C：执行应急计划 Execute response plan
 
 D：执行风险转移 Perform risk transfer
 
**正确答案：C； 你的答案：C**
> 解析：PMBOK（6）P439-11.5规划风险应对。针对发生的已识别风险制定应急计划。
>  
> 题干当中提到：从原定备用供应商那里获取产品，有备用的计划，这个是典型的应急计划


### 5.3 新工具/最佳资源 = > 开拓

（模3）134、 [单选] 在一个软件开发项目中，开发人员发现一个可以提高速度的新工具。项目经理分析发现这种新工具能够缩短当前开发阶段20%，并节省10%的项目成本。在变更控制委员会批准之后，项目经理修订了项目进度。这属于哪种风险应对类型？During a software development project, a developer discovers a new tool that could increase development speed. The project manager’s analysis finds implementing the new tool could shorten the current development phase by 20% and save 10% of the project’s cost. After approval from the change control board, the project manager revises the project schedule. What is the type of risk response?

 A：开拓 Exploit
 B：接受 Accept
 C：增强 Enhance
 D：转移 Transfer
 
**正确答案：A；  你的答案：A**
>  解析：11.5规划风险应对，积极风险的应对，开拓，关键字包括**新工具，最佳资源**

### 5.4  PM监督一个不可控制的风险=> 应急储备/上报。 但是上报不是上报给外部方（External Party）..
（冲2）103、 [单选] 项目经理正在监督一个不可避免、不可控制、也无法转移的严重风险,由于这个风险需要额外的资金,项目经理应该做什么?A project manager is overseeing a serious risk that is neither avoidable,controllable,nor transferable.Since this risk requires extra funding,what should the project manager do?

 A：执行定性风险分析。 Perform a qualitative risk analysis.
 
 B：将该风险升级上报给一个外部方。 Escalate the risk to an external party.
 
 C：减轻风险。 Mitigate the risk.
 
 D：使用应急储备。 Use the contingency reserve.
 
**正确答案：D；  你的答案：B**
> 解析：由题意得，对于“已知-未知”的风险，使用应急储备。见PMBOK6版7.2.2.6 储备分析，题干可知，不可避免控制和转移，所以C不对，同时因为正在监督，说明已经完成了风险分析。B上报给一个外部方不正确。

### 5.5 一道值得复盘的题：如何用排除法选出过程的输入项

（冲3）3、 [单选] 项目经理领导一支经验丰富的团队，该团队由职能员工和顾问组成，在一次特色全国性活动上为一项成功产品推出促销版本，该产品版本必须及时推出。**`制定风险管理计划时`**，项目经理应该怎么做？The project manager leads an experienced team of functional staff and consultants who release a promotional version of a successful product that must be releaseed in time for a unique national event. What should the project manager do when developing a risk management plan?

 A：采用风险共存方法来处理项目风险，因为这种产品版本将是短暂性的 Use risk coexistence methods to deal with project risks, as this product version will be transient
 
 B：执行预期货币价值（EMV）分析，确定成功概率 Perform Expected Monetary Value(EMV) analysis to determine the probability of success
 
 C：使用初始产品发布中的风险核对单 Use the risk checklist in the initial product release
 
 D：与团队一起头脑风暴识别风险 Brainstorming risk with the team to identify risks
 
**正确答案：C； 你的答案：D**
> 解析：定位：（管理）规划风险管理。 说明解析：PMBOK（6）P403-11.1.1.5规划风险管理过程输入组织过程资产。包括以往类似项目的信息、模板等。 
> 
> **选项A：规划风险应对过程-消极风险应对策略-接受。** 
>  
> **选项B：实施定量风险分析过程。** 
>  
> **选项D：识别风险过程**

### 5.6  对已批准的产品进行变更，相关方不同意=>创建变更请求

（冲3）38、 [单选] 某位项目相关方要求对已批准的产品设计进行变更，程序员仅需少量工作就可进行这项变更。**`但是存在一个风险`**，即另一位相关方将不同意这项变更。项目经理应该怎么做？ A project stakeholder requires a change to an approved product design.To accommodate the change,minor efforts are required of programmers.However,there is a risk,however,that another stakeholder will not agree to this.

 A：由于不存在重大的财务影响，因此实施这项变更 Implement the change as there is no significant financial impact
 
 B：根据变更管理计划创建一份变更要求 Create a change request in accordance with the change management plan
 
 C：请求项目发起人的批准 Request approval from the project sponsor
 
 D：与相关方谈判接受这项变更 Negotiate the acceptance of the change with relevant stakeholders

**正确答案：B；  你的答案：D**
> 解析：定位：（管理）规划风险应对。 说明解析：**PMBOK（6）P447-11.5.3.1规划风险应对-变更请求**。
>  
>  规划风险应对后，可能会就成本基准和进度基准，或项目管理计划的其他组建提出变更请求，应该通过实施整体变更控制过程对变更请求进行审查和处理。已识别到存在一个相关方不同意的风险，规划风险应对。
>   
> 选项A：不符合题意。 
>    
> 选项C：发起人无法批准不同意的变更。 
>     
> 选项D：相关方有自己的诉求，这个诉求是一个风险，规划风险应对是首选，因对办法可能包括跟相关方谈判，还可能有其他的办法，选D不合适。
>  
>  这题我之所以选错，是因为题干当中【已批准】的变更干扰到我，让我一直以为，已批准的变更就应该被执行，相关方不同意那就说服他.... 其实题干是问，如果需要提变更，**相关方担心有风险不愿意变更怎么办？那就跟相关方一起分析风险，规划应对，让后再根据分析结果，考虑上反对方的意见提变更**。

### 5.6 影响交付延迟=>风险问题=>上报通知告警都属于风险管理计划，其次才是沟通管理计划
（冲2）42、 [单选] 一位团队成员通知项目经理，供应商延迟交付一个重要部件，由于潜在的影响，该团队成员希望项目经理允许直接通知发起人并生成与这种情况相关的警报。项目经理应该查阅哪一份计划？A team member notifies the project manager that an important component has been delayed by a vendor.Because of the potential impact,the team member wants the project manager’s permission to inform the sponsor directly and to generate an alert related to the situation. Which plan should the project manager review?

 A：采购管理计划 Procurement management plan
 B：沟通管理计划 Communications management plan
 C：相关方参与计划 Stakeholder’s engagement plan
 D：风险管理计划 Risk managemen plan

**正确答案：D；  你的答案：B**
> 解析：供应商延迟交付属于风险问题，后续系列动作属于风险汇报，应先更新风险管理计划，其次再是沟通管理计划。
