# Markdown New Skill, Get
@(工具篇)[Markdown, Markdown 特殊符号, Markdown 奇技淫巧]

[toc]

## 常用技巧
| 雕虫小技 |     实现 |   
| :-------- | :--------|
|下划线|<span style="border-bottom:2px dashed red;">所添加的需要加下划线的行内文字</span>|
|下划线2|<u>哈哈哈哈哈哈哈</u>|
|锚点|< a href="#文档修订记录">文档修订记录</a>|
|锚点2| [文档修订记录:](%E6%96%87%E6%A1%A3%E4%BF%AE%E8%AE%A2%E8%AE%B0%E5%BD%95) <br>[文档修订记录]\(#ID or URL) |
|首行首列|table td:first-child, table th:first-child { <br>min-width:100px;<br> }
|断行|< br>|
|改变字体大小|<font size=5> Scheduled Maintenance -  Brightpearl USE <font>|
|改变字体颜色|<font color=gray>Components affected</font>|

基本上，html支持的样式，markdown也支持，所以如果需要特殊的样式，需要先熟悉一下html本身的标签内容。

## 设置默认表格的宽度

问题描述：

有时候我们需要对MD自带的表格宽度进行调整设置，因为默认的表格会如下的尴尬问题：
![@||400x0](./1577323968042.png)









### **解决办法一：**
在首行首列加入大量的  ` & nbsp;`
![Alt text](./1577324021305.png)






### **解决办法二：**
在马克飞象加入全局样式调整：

![@||250x0](./1577324344909.png)










![@||400x0](./1577324363200.png)














```css
table td:first-child, table th:first-child {
   
  min-width:100px;
}
```

### **解决办法三：**
直接在MD的表格内写span样式：

![@||500x0](./1577324495131.png)

```css
<span style="display:block; width:80px; "> <span>
```

其中方法三的效果最好，如图所示：
![@||550x0](./1577324557190.png)








## References & Connection
1. [Markdown 语法快速入门手册 --W3C School](https://www.w3cschool.cn/markdownyfsm/markdownyfsm-odm6256r.html)


## 文档修订记录

| 版本号|     变化状态|   简要说明|  日期	|   变更人/参与者   |
| :-------- | :--------| :------ |:------ |:------ |
| V1.0|   New| 新建文档 |2019-12-7  | Lee|
| V1.1|   Edited|添加toc，添加文档修订记录等 |2021-2-18 | Lee|

*变化状态：New，Edited，Added，Deleted