# Interview Practise
@(Interview)[Practise with myself, English Interview]


[toc]

























## Preface

我还记得，当我还是初中生的时候，我和我弟弟跟我舅舅学过一阵子的功夫。舅舅是当时镇上远近闻名的功夫行家，几个小流氓要在他电影院刷威风，一招就被舅舅制伏不能动弹，几个小流氓自知不敌，在电影院在众目睽睽之下，灰溜溜的溜走了，从此舅舅一战成名。

舅舅是典型的儒家弟子，内圣外儒，喜欢祭拜孔子和毛泽东，因此对于亲人也是倾其所能去帮助，不会私藏。

舅舅要我们每天扎马步2个小时，之后再打一套拳法，每天如此，反复一个月多月，对我们来说是异常的艰苦，弟弟不到2个礼拜就放弃逃跑了，我坚持不到2个月也尿遁了。

然后现在回想起起来，我逐渐明白了一些道理：天下武功，尽是先从套路起步，反复刻意练习，需要长时间积累，到了一定的境界，才能入门更高阶的功法，进而才会对天赋有所要求。

**天赋决定了你能达到的上限，努力程度决定了你能达到的下限。以绝大多数人的努力程度之低，远远没有达到拼天赋的地步**。

在我的内心里面，其实一直对模板和套路有相当的抵制，觉得日常和工作中，需要随机应变，张口既来，因此对平时的英语口语学习，缺少了有针对性的刻意练习。

但这其实是错误的想法。套路和模板不仅可以短期内在有针对性的领域大幅提升表现，也可以跨出它所在的领域影响到各方面。最好的例子，就是我在10年前马尾，每天30-60分钟的不断练习发音，由此入门，掌握了自然拼读法，大幅扩大单词库，也为连读这些打下基础；

另外我在头马获得过的Table Topic演讲名词，也是短时间内刻意模仿各个冠军的结果；最早期上台的我，表无表情，疯狂眨眼睛的，也是有一阵子使用了套路刻意练习，一场演讲甚至做了4~5次才逐渐克服的。

然而反观近期（2018~2020），虽然我也系统的去学习一哈佛大学公正课，但是由于基础不牢，很多课程也仅仅蜻蜓点水的过了一遍有个概念，缺乏深入的反复练习背诵，因此这2年的口语水平我自己并不满意。要知道前几年我对自己口语是很自信和满意的，我甚至敢大言不惭的跟一个英国人讨论他的RP音不是很准，一方面我年轻无知，另一方面又何尝不是自己对满意自信的体现吗。

我想这就是为什么我要搭建这些手脚架模板的原因，我需要反复打牢我的基础，正如练武之人需要反复扎马步和练拳一样。我需要一个能让我在面试上脱口而出，在table topic上自信表达的马步。

























## 0. Technical Interview

### 1). Contrast the strengths and capabilities of NoSql and RDB. Explain in context of performance and distributed systems.  
> One google search away. NoSql has higher throughput read/write, very suitable for datasets that are not relational. I had almost no experience with NoSql.

### 2). How exactly does Hashmaps work. How do they hash values? How exactly arethe values retrieved in the implementation? Explain with the use of Big O Notation  


### 3). Name a circumstance where you solved a crisis/big issue and how you had handled it  

### 4). How do you usually handle criticism?  

### 5). If you had a massive stored procedure and you needed to ensure that it works correctly with no failure. Backed with thirty developers and two months, how would you go about testing it?  

### 6). Find the biggest number in an array of unique integers as efficiently as possible. 
> The answer is something to do with heapsort/quicksort and Big O Notation with a run time of O(n *log n) or something like that.  

### 7). Contrast the fundamental differences between a multithreaded process and an asynchronous process. Preferably in the context of c#.  

1. [What is the difference between asynchronous programming and multithreading? -- StackOverflow](https://stackoverflow.com/questions/34680985/what-is-the-difference-between-asynchronous-programming-and-multithreading#:~:text=In%20multithreaded%20workflows%20you%20assign,of%20the%20just-completed%20task.)

### 8). Describe one tech thing you learnt recently and learnt well.  

### 9). How would you speed up a stored procedure or a database's performance?  

### 10). What are DB Indexes? What are the advantages and disadvantages?  

Used to speed up queries. Formed from multiple columns usually. They need to be updated. They take up some space. Primary key by default is an Index but you can make your own for really busy tables. Usually good for tables with loads of data you can't search from the beginning to end cause it takes too long.

- **参考**
1. [Software Engineer Interview --  WiseTech](https://www.glassdoor.com.au/Interview/WiseTech-Global-Software-Developer-Interview-Questions-EI_IE658123.0,15_KO16,34.htm)

## 1. PM Interview

### 1.  Introduce yourself

This is Lee here, and I am very pleased to apply **for** product manager, I think I am quite suitable for this position because 
- **First of all**, I have more than 6 years of product management experience,  quite familiar with market research, competitive product analysis, product requirement analysis, product designing and reviewing with team members, and finally, product releasing and validating. 
> Avoid using [product life cycle managemne](https://zipinventory.com/product-lifecycle-management.html)t, because it involves a big picture, including the industry, marketing, and business model of your company. 
- **Meanwhile**, I used to be a software developer for more than 6 years from 2007 to 2014, So one of my strengths to be a product manager is that I am good at communicating with the RD team because I know how to accurately translate the product requirement into the way of understandable specifications and acceptable by RD.
- **In addition**, I took the PMP (Project Management Professional) exam and got the certification with 5 A in 2019 as well.  It helps me to get a big picture of software engineering projects. 
- **Last but not least,** I have been a member of Toastmasters for more than 6 years. Toastmasters is a non-profit organization that focuses on members' public speaking and leadership training.  It helps me significantly improve my communication skill and leadership.


I've graduated in 2007,  since then, I've been an employee in [Silverlake Axis Group](https://www.linkedin.com/company/silverlake-axis-ltd/?trk=organization-update_share-update_actor-image) as a junior software engineer.  I have worked in this company for more than 4 years. 



### 2. Why would you transfer your career job from RD to PM? 

### 3. And why you return back now?

### 4. How do you handle a new requirement?


### 5. How did you start with a new product?


### 6. What is the Product Manager?

分为三个层次

### 7.  What do you know about our comany?

### 8. What and how agile 

### 9.  How do you plan the product roadmap?


1. [产品经理应该如何规划产品线路图？ -- 知乎](https://www.zhihu.com/question/63020639/answer/1359867158)



### 10.  User Profile: What-Why-How

1. [用户画像的基础、原理、方法论（模型）和应用 --刘启林 --知乎](https://zhuanlan.zhihu.com/p/140104236)


### 11 .  How do you collect requirements?  => the process of requirement analysis.

- Stakeholders interview
- 用户画像、需求调研: 通过用户调研、数据分析等手段找到用户的需求点。
- data analysis:根据数据指标，衡量产品的薄弱点，评估新功能的效果
- users feedback
- competitive product: 关注竞品动态，比较彼此的商业模式和运营思路。
- market research

商业分析：发现精准驱动点，带来可持续收入增长，这一点很多人都做不到，但这才是企业的命根子。

## . 文档修订记录

1. [Product manager interview prep (relax, start here)](https://igotanoffer.com/blogs/product-manager/pm-interview-prep)
2. [Google PM interview: the only post you'll need to read](https://igotanoffer.com/blogs/product-manager/google-product-manager-interview)
3. ![Alt text](./王力-6年产品经验.docx)
4. [外企面试的时候英语自我介绍该说点什么？](https://www.zhihu.com/question/19666878/answer/1910689754)


| 版本号|     变化状态|   简要说明|  日期	|   变更人/参与者   |
| :-------- | :--------| :------ |:------ |:------ |
| V0.1|   建立| 文档初建 |2019-11-25  | Lee|
| V1.0| 增加| 1. 新增 `7. What do you know about our comany?`章节|2020-2-14|Lee|

*变化状态：建立，修改，增加，删除
