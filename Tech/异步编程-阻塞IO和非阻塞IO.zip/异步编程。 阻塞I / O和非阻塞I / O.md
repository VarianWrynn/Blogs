# 异步编程。 阻塞I / O和非阻塞I / O
@(技术扫盲帖)[Asynchronous programming]

[toc]


![Alt text](./1619011230274.png)












这是异步编程系列文章的第一篇。整个系列文章都试图回答一个简单的问题: "什么是异步?"。一开始，当我开始研究这个问题的时候，我以为我知道它是什么，最后我才发现我对所谓的异步一无所知。

那我们开始吧，其他系列的文章包括：

-   [Asynchronous programming. Blocking I/O and non-blocking I/O](https://luminousmen.com/post/asynchronous-programming-blocking-and-non-blocking)
-   [Asynchronous programming. Cooperative multitasking](https://luminousmen.com/post/asynchronous-programming-cooperative-multitasking)
-   [Asynchronous programming. Await the Future](https://luminousmen.com/post/asynchronous-programming-await-the-future)
-   [Asynchronous programming. Python3.5+](https://luminousmen.com/post/asynchronous-programming-python3.5)



在本文中，我们将讨论网络的异步编程，但以你的智商，应该可以轻松地举一反三把知识拓展到其他I/O异步操作（比如：文件）。 同样，我在解释异步编程过程中，我不会限制在特定的语言中，虽然本文是以Python给出代码示例（但我能说什么-虽然我这么喜欢Python！）。

另外，在大多数情况下，当你对阻塞和非阻塞编程有疑问的时候，通常意味着你需要与I/O打交道。因为在我们这个信息、微服务和lambda函数时代，最常见的情况是请求处理（request processing）。

你可以想象自己是一个web站点的用户，而你的浏览器(或您正在读取这篇文章的应用程序)是一个**客户机**。在Amazon的某个地方，有一个**服务器**处理你的传入请求，迅速的生成你将要读取的文章。

为了在这样的**客户机-服务器**通信中启动交互，客户机和服务器必须首先建立彼此之间的连接。我们这里不会不深入讨论这种交互所涉及的7层模型和协议栈，因为这一切都可以很容易地在互联网上找到。

我们需要了解的是，在两端(客户端和服务器)都有称为套接字的特殊连接点。客户机和服务器都必须绑定到对方的套接字上，并监听它们以理解在线路的另一端对方说了什么。

![@||500x0](./1619013621117.png)







在你阅读这篇文章的过程中，服务器需要做一些事情： 要么处理请求，将markdown转换为HTML，要么查看图像所在的位置，总之它会视情况处理某种请求。


![Alt text](./1619013762489.png)














如果你看一下CPU速度和网络速度之间的比率，你会发现差别是几个数量级的。如果我们的应用程序大多数时候都使用**I / O**，则在大多数情况下，CPU的处理器（processor）根本不执行任何操作。 这种类型的应用程序称为**I / O绑定**(I/O-bound)。 对于要求高性能的应用程序来说，I/O bound 是一个瓶颈，这也是我们接下来要讨论的。


有两种管理(organize)I / O的方法（我将基于Linux给出示例）：**阻塞（blocking ）**和**非阻塞（non-blocking）**。

同样的，有两种类型的I / O操作：**同步（synchronous）**和**异步（asynchronous）**。

它们共同构建了一组 **I / O模型**。


![@||630x0](./1619014167535.png)













这组I / O模型中，每一个模式的都是对某种特定应用程序有利的。 在这里，我将演示两种管理I / O的方式之间的区别。


##  阻塞I/O  (Blocking I/O)

使用阻塞的 I/O，当客户端向服务器发出连接请求时，处理该连接的套接字和从中读取（数据）的相应线程将被阻塞，直到读取出一些数据为止。这些（被读取出的）数据会放置在网络缓冲区（buffer）中，直到它全部被读取并准备好进行处理。在整个操作完成之前，服务器**只能等待，做不了其他事情**。

据此我们可以得出一个最简单的结论是，（在阻塞I/O模式下，）我们不能在一个线程中使用一个以上的连接。默认情况下，TCP套接字工作模式就是阻塞模式。

简单代码示例（Python）:

- **客户端**：

```python
import socket
import sys
import time


def main() -> None:
    host = socket.gethostname()
    port = 12345

    # create a TCP/IP socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        while True:
            sock.connect((host, port))
            while True:
                data = str.encode(sys.argv[1])
                sock.send(data)
                time.sleep(0.5)

if __name__ == "__main__":
    assert len(sys.argv) > 1, "Please provide message"
    main()
```

在这里，我们以无尽的循环向服务器发送间隔为50ms的消息。 可以想象成，这里的客户端与服务器之间的通信包括下载一个大文件，需要相当长的时间才能完成。

- **服务端**：

```python
import socket


def main() -> None:
    host = socket.gethostname()
    port = 12345
    
    # create a TCP/IP socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        # bind the socket to the port
        sock.bind((host, port))
        # listen for incoming connections
        sock.listen(5)
        print("Server started...")

        while True:
            conn, addr = sock.accept()  # accepting the incoming connection, blocking
            print('Connected by ' + str(addr))
            while True:
                data = conn.recv(1024)  # receving data, blocking
                if not data: 
                    break
                print(data)

if __name__ == "__main__":
    main()
```

我在具有多个客户端的单独终端窗口中运行此命令，如下所示：

```
$ python client.py "client N"
```

## 非阻塞I/O (Non-blocking I/O)


## 多任务 (Multitasking)

## Separate processes

## Threads



## References & Connection

1. [Asynchronous programming. Blocking I/O and non-blocking I/O](https://luminousmen.com/post/asynchronous-programming-blocking-and-non-blocking)
